Check whether all these files are in the FSX main folder. 

Pr�fe, ob alle diese Dateien sich im Hauptordner des FSX befinden.

V�rifier que les fichiers sont pr�sents dans votre r�pertoire principale du FSX. 
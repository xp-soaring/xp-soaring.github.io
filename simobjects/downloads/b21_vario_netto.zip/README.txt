INSTALLATION INSTRUCTIONS FOR THE NETTO VARIO

For these instructions, the main fsx folder will be referred to as "FSXMAIN".

On a default FSX install this will be "C:\Program Files\Microsoft Games\Microsoft Flight Simulator X\".

1) drag the Gauges folder from this zip file into FSXMAIN, 
   so you now have a "FSXMAIN\Gauges\b21_vario_netto" folder.

That's it! You now have the netto vario installed and available for use in any panel.

"But" I hear you say - "How do I insert the netto vario into the panel of my DG808S?"

sheesh...
###############################################################################################################

If that's what you want, follow these instructions:

1) in Windows Explorer, navigate to "FSXMAIN\SimObjects\Airplanes\DG808S\panel\"

2) open "panel.cfg" using your favourite editor, e.g. Notepad

3) the [VCockpit01] section (near the end of panel.cfg) by default looks something like:

[VCockpit01]
file=DG808s_Panel_Gauges_2.bmp
size_mm=256,256
pixel_size=256,256
texture=$DG808s_Panel_2
background_color=0,0,0

gauge00=DG808S!asi, 10, 13, 103, 104
gauge01=DG808S!variometer, 14, 152, 90, 90     <---- THIS IS THE ONLY LINE YOU WANT TO CHANGE !!!!!!
gauge02=DG808S!vsi, 147, 154, 84, 84
gauge03=DG808S!nav_display, 130, 5, 121, 122

and you want to change the entry for gauge01 to point to your new installed Cambridge vario instead:

gauge01=b21_vario_netto!variometer, 14, 152, 90, 90

###############################################################################################################
That really is it - now go fly.  In still air, the Cambridge vario should hover around zero regardless of what
speed you are flying (although it will correctly show energy loss if you pull up, or open the airbrakes).
The netto is designed to be a reasonable approximation assuming the right flap setting.

If you're flying with CumulusX! and sim_probe, the netto vario will be invaluable in giving you
an insight into what the hell the air is doing outside your plane, particularly on the ridges.

Note that the netto vario is computing in real time the total energy parameters of your current trajectory,
and adding back in computed sink relating to your glider's polar curve (i.e. sink rate vs. speed) and all
this is totally MEANINGLESS in slew mode.


Sim_logger Version 2.31 INSTALL INSTRUCTIONS

For more information see:
 http://carrier.csi.cam.ac.uk/forsterlewis/soaring/sim/fsx/dev/sim_logger/

WARNING!  If you use CumulusX, ignore this warning.

          If you are *not* using CumulusX for your thermals (e.g. Active Sky)

          Please be aware sim_logger will DISABLE FSX THERMALS by default, on the 
          assumption that CumulusX is being used for thermals.  A sim_logger.ini
          file setting (disable_fsx_thermals = false) (see step 6) will ensure
          sim_logger leaves your FSX thermals in place. The default value
          (disable_fsx_thermals = true) means sim_logger will rename your
          "ThermalDescriptions.xml" to "ThermalDescriptions[X].xml", so
          to reverse-out the change all you have to do is rename it back.


Step 1. DOUBLE-CLICK on the zip file containing this readme so it opens in
        Windows Explorer - as you're reading this you probably have done
        this already.

Step 2.DOUBLE-CLICK the vcredist_x86.exe in the ZIP file, or
       download the file and run it from
        http://www.microsoft.com/downloads/details.aspx?familyid=9B2DA534-3E03-4391-8A4D-074B9F2BC1BF&displaylang=en
       This will install the Microsoft VC++ Runtime needed for the module,
       and is safe to install even if you already have it.

Step 3. DRAG the 'Modules' folder from this ZIP file into your FSXBASE
        folder (e.g. C:\Program Files\Microsoft Games\Microsoft Flight Simulator X").
        The 'Modules' folder should already exist but this will put the
        new 'sim_logger' add-on module in there.

Step 4. DRAG the 'Flight Simulator X Files' folder from this ZIP into
        your "My Documents" folder. The folder should already exist but
        this step will put some new flights in that folder.

Step 5. OPEN Windows Explorer and navigate to the new "FSXBASE\Modules\sim_logger" folder.
        DOUBLE-CLICK on the UPDATE_XML.cmd file.
        This will create the appropriate entry in your "%APPDATA%\Microsoft\FSX\exe.xml"
        file, to include the sim_logger add-on automatically at FSX startup.

Step 6 (optional). You can EDIT the 'Modules\sim_logger\sim_logger.ini' file to
        change the language used for the menus (we currently have en, de, nl) and
        to preset your 'Glider ID' (pick 3 letters or numbers) and 'Pilot Name'.

Step 7. Start FSX, and in "Settings->Realism" in the "Crashes and damage" section
        UNCHECK "allow collisions with other aircraft".
        If you don't do this, your user aircraft will IMMEDIATELY collide with any
        aircraft loaded from a prior saved tracklog.
        A screenshot is available for this setting at the web address give at the
        top of this readme.

THAT'S IT!

To confirm sim_logger is installed simply start FSX and load any flight, and you
should see a Add-Ons->Sim_logger sub-menu. Usage information is given at the
web address given at the top of this readme.

During any flight, you can click "Add-ons->Sim_logger->SAVE an IGC file now" and
a standard-format tracklog file will be stored in your "Flight Simulator X Files"
folder in a sub-folder with the same name as the loaded flight.

Sim_logger will automatically REPLAY stored tracklog files when you load the
corresponding flight.  For a demo, load the flight
"Schuylkill County Ridge Run". While paused at the start, you can select another
aircraft or keep the DG808S, unpause, wait a couple of seconds and you'll see
a fleet of other gliders launch ahead of you, and then Control-Shift-Y to call
an aerotow.

If you need help or have questions or just want to say how great it is getting
software for free, use the SOAR sim_logger forum:

http://www.forum.aerosoft.com/index.php?showforum=233

THANKS - to Bert de Bruin and Peter Luerkens for development comment and advice,
and the beta-testing.

Ian Forster-Lewis
February 2010

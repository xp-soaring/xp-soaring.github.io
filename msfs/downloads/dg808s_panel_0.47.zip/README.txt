##############################
# DG808S B21 Instruments v.44
##############################

* Assumes you've already installed the FB Group DG808S

* copy the "dg808s_panel" folder to:
   /Community/legacy-vcockpits-instruments/html_ui/Pages/VLivery/liveries/Legacy/

* copy the "layout.json" to /Community/legacy-vcockpits-instruments (overwriting the one already there)

* (optional - as a quick improvement I've changed the vario pitch rate and removed the fuel pump sound):
  copy the "sound.xml" file to
  /Community/<whatever you've called the dg808s folder>/SimObjects/Airplanes/DG808S/sound/

##############
# SUMMARY USAGE:
##############

The instruments will work fine "out-of-the-box" with the Cambridge Vario auto-switching between CRUISE and CLIMB modes.

HOT-KEYS:

Assign a key/button to "TOGGLE BEACON LIGHTS" to manually switch the Cambridge vario to CRUISE or CLIMB.

Assign a key/button to "TOGGLE NAV LIGHTS" (default "Alt-N"?) to select NEXT WAYPOINT in Nav Display (if you have a flightplan loaded).

Assign a key to "TOGGLE CABIN LIGHTS" (default "Alt-T" I think) to show/hide debug readings.


#########################################
# Nav Instrument / LOADING A FLIGHT PLAN
#########################################

The Nav Instrument tells you
* the name of the selected waypoint
* a pointer for the direction to go
* the altitude of the waypoint
* the distance (in Km) to go

Flight plans are not essential, but we can use them to define a soaring cross-country task.

If you start the flight with no flight plan loaded, the Nav instrument will populate a single waypoint for your starting position,
calling that 'HOME'. This isn't a bad place to start with a launch followed by a glide back to the airport following the Nav
pointer, including in a cross-wind.

If you load a flight plan (before starting the flight) then the Nav Instrument will read that and display the first waypoint. You can
select further waypoints via the hot-key/button assigned to "TOGGLE NAV LIGHTS" (default Alt-N).

You can use 'Alt-N' (by default) to step through each waypoint on the Nav Instrument. Technically in MSFS you are toggling the
Nav lights but this is a workaround to enable you to interact with the Nav Instrument.

You can create your own MSFS flight plan with Little Nav Map (or Plan G).

MSFS has it's own idea for what to do with the ALTITUDES
in your flight plan and this makes those altitudes irrelevant for soaring. If you append "+<altitude feet>" to your waypoint NAME
e.g. "START+4000" then in this example the Nav Instrument will display 4000 (feet) for the "START" waypoint. This will be more
important if/when I add 'estimated arrival height' as a function of the Nav instrument.

An example Mifflin_Day1.pln MSFS flight plan for a soaring task is included.

See https://xp-soaring.github.io/fsx/missions/mifflin/overview.htm

Set the wind for 315 degrees / 17 knots / no gusts. This is harder than it sounds so ask the FB ground if you're unsure.

##########################
# Winter Vario
##########################

The Winter vario is permanently showing Total-Energy Compensated Sink Rate.

If you are flying at a steady speed, this is identical to the speed you're sinking towards the ground.

If you are accelerating/decelerating then the gauge compensates for that making the underlying sink rate easier to see.

######################
# Cambridge Vario
######################

The Cambridge Vario has 3 modes (toggle with hot-key/button assigned to "TOGGLE BEACON LIGHTS"):

AUTO MODE:
* icon at 3-o-clock will be blank (cruise) or a circle-arrow (climb)
* Average at 6-o-clock will be:
    - cruise: rolling average Netto
    - climb: true climb average since entering climb mode.
* Needle and Audio will be:
    - cruise: Netto
    - climb: TE

In AUTO MODE the gauge will switch sensibly between the AUTO-CRUISE and AUTO-CLIMB modes, e.g. a variety of different situations will
cause the gauge to operate in AUTO-CLIMB mode (needle showing TE climb rate, AUDIO on TE, averager giving you the TRUE climb rate
since you entered this mode). For example, selecting flaps T1 or T2, flying below 70 knots in rising air will cause the
Cambridge vario to assume you are trying to thermal. Flying fast, or simply flying in a straight line without climbing, will cause
the vario to exit climb mode.

CLIMB MODE:
* icon at 3-o-clock will say "TE"
* Average at 6-o-clock will be rolling average TE
* Needle and Audio will be TE
* The vario will remain fixed in this mode, with no auto-switching

CRUISE MODE:
* icon at 3-o-clock will say "Net"
* Average at 6-o-clock will be rolling average Netto
* Needle and Audio will be Netto
* The vario will remain fixed in this mode, with no auto-switching

##########################
# General info
##########################

Power on/off (default Alt-B) should work as expected. The instruments should cope with 'slew mode' and 'pause' ok.
I have NOT yet programmed the Cambridge 'true average' to detect pause/slew yet.

There is a hot-key (whatever you have assigned to "TOGGLE CABIN LIGHTS" ) to bring up DEBUG DATA including glide ratio.

* ASI has (top) TRUE AIRSPEED (bottom) GROUND SPEED kph
* Nav has (bottom left) GLIDE RATIO
* WINTER has (bottom) TE m/s
* Cambridge has (bottom) Netto m/s.

The Netto is calibrated with the correct polar, so in STILL AIR if you're flying properly (e.g. in the right flap, wheel up,
spoilers closed) it should read zero. Any difference is the sim flightmodel error or you are not flying in still air (easiest
check is the L/D in the Nav display).

MSFS gusts are not sensibly implemented currently, so you need to disable those or will have excessive jitter in the vario needles.

Competition Task 1
P. L�rkens

Task Description

This is an experimental competition task for use with FSX and CumulusX!. Task1 starts and ends at airfield Aachen Merzbruck, EDKA, for a course of 234.5 km. Weather is pretty good, ceiling is approx. 1800 m MSL, average lift aroun 3 m/s. The task goes from Aachen to the south, first turnpoint is Dahlemer Binz, EDKV, from here to south-east to second turn point "Koblenz Winnigen, EDRK". Then it turns back to north-west, third turnpoint is "Bad Neuenahr-Ahrweiler, EDKRA", which is close to the home of former Formula 1 driver Michael Schumacher. Then return back to Aachen Merzbruck. Time to complete will be around 2.5 hrs.

Requirements

* Some FSX glider aircraft
* CumulusX! 1.5 Thermal software (www.luerkens.homepage.t-online.de)

Recommended

* Europe SRTM Mesh (e.g. @ flightsim.com)
* German landclass (www.germany-vfr.de, can only be installed if it detects fs9)
* Sim_probe or CAIset for logging

Deactivation of default thermals
For sprtsman-ship I emphasize the deactivations of default thermals. Before starting FSX, go to FSX installation directory and rename the file "ThermalDescriptions.XML" into "ThermalDescriptions.XML.defunct". This deactivates the huge FSX default thermals. By removing ".defunct" these are re-enabled again.

Installation
Extract the zip into some temporary folder. Extract the files from the subdirectory "Microsoft Flightsimulator X-files" into the directory, that is used to hold Flightsimulator files.
If you use gliders with Max Roodveldt's CAISet, extract the files from the subfolder FSX into the installation directory of FSX. Make backup copies of the files GPS-NAV.DAT, LNAV.dat and, Soarrec.log, if they exist there.

Usage
Simple load the flight "Task 1" from FSX menu. After that CumulusX! uners interface is locked and prevents you from (inadvertedly) changing the settings. Then choose your aircraft. You may need to adjust you starting position, because I use my own EDKA scenery. you should find the flight plan of the task in your GPS, or the C4, in case of the aerosoft discus. If you use CAISET from Max, then you should find your flight there, too.

Rules
Starting window is between 12:00 and 13:00 local time, maximum altitude 1200 m MSL. I.e. you should open the task by crossing the start gate not before 12:00 and not after 13:00, and not higher than 1200 m MSL. The starting gate is a line perpendicular to the first leg, through the center of EDKA.
Then fly to the turnpoints in the given order. Fly round the turnpoints on the outer side of the course. When you return to EDKA, finish the flight by either crossing the gate (which is now perpendicular to the last leg) in at least 150 m AGL, or land.
 
What you should not do:

* Slew after crossing the start gate
* Change of aircraft during flight
* Change weather conditions
* Change CumulusX! settings

After completion
Make a flight analysis with a screen shot of your entire flight path, including altitude profile. Determine crossing of the start and finish gates to determine task time. You may do it as well with usual flight evaluation software. Post the results in the SOAR forum.

Have a lot of fun (BTW, I did not complete it yet)

Best regards,
Peter



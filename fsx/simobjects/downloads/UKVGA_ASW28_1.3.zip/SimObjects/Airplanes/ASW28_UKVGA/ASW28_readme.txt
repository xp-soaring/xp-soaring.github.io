Schleicher ASW28 Prototype D-8028

The Glider
   The ASW28 is the latest standard class development to come from Schleicher's drawing boards. It is, in itself, a development of the ASW24, utilising the same basic fuselage. It employs the latest in design to build strength and crash protection around the cockpit to maximise pilot safety and also comes with the option of a ballistic rescue parachute to further aid this. The ASW28 owes is excellent flight characteristics to the completely new wing, and thus achieves a maximum glide ratio of 45:1 at 50kts (90km/h).

Specifications
   Wingspan:		15m
   Wing Area:		10.5m�
   Aspect ratio:	21.43
   Empty weight:	235kg
   Max T/O Weight:	525kg
   Wing loading:	29-50kg/m�
   Max Water Ballast:	180L
   Maximum speed:	158kts (285km/h)
   Stall speed:		39kts (70km/h)
   Minimum sink:	0.55 m/s
   Maximum glide ratio:	45:1 at 50kts (90km/h)


The Model
   After several reincarnations, the model is finally finished (but is it???). What started out as a fairly advanced FSDS model was soon ported over to gmax with the arrival of FS2k2. It then underwent several rebuilds and refining to where it is now.
   Following the rapid advancement in the knowledge of gmax, the model also followed these developments to where it is now. This includes:
   - a highly detailed model with a fully designed cockpit;
   - an accurate virtual panel in both virtual cockpit view and also from the exterior;
   - a working yawstring in the 3D model;
   - opening canopy and instrument panel (via Shift+E1), and a sometimes working Clear-view panel (via Shift+E2);
   - a fully textured model where virtually all visible surfaces are textured independently (allowing for completely unique repaints with no texture mirroring);
   - 100% accurate motion of the Schemp-Hirth airbrakes (just test them out and you'll be suprised);
   - a fully animated pilot (his legs work the rudders, and arms are fully animated to the control column);
   - in the event of a very hard landing, the fuselage boom will break resulting in the fin being left in the typical position after this event.


The Panel
   The panel is based on a photograph provided by Roland Stuck. It features accurate gauges (designed by who else but Max Roodveldt). A radio is available by pressing Shift+5 which brings up an overlay over the altimeter. For a detailed set of instructions on how to use the L-NAV and GPS-NAV instruments, instructions can be found on Max's website www.fszwever.com
The panel also has the controls to manage the water ballast tanks.

The windows are as follows:
   - Main Panel (Shift+1)
   - Mini Controls (Shift+2)
   - Yawstring (Shift+3)
   - Moving Map (Shift+4)
   - Radio (Shift+5)

   If you fly in the virtual cockpit view, you must switch back to the 2D panel in order to control the gauges. You can either cycle through the views, or press 0 on your number pad to momentarily view the 2D panel.

Notes
   If you are using the throttle axis of your joystick to control the spoilers, I recommend that you follow the instructions by Al Stirling (in the SOAR Library) on how to correctly calibrate this to avoid the slightly deployed spoilers from occuring.
   If you would like a detailed texturing template in order to do a repaint, please do not hesitate to send me an email asking for such.

Links
   Max Roodveldt's site:	www.fszwever.com
   SOARVirtual Soaring:		www.virtualsoaring.org

Acknowledgements
   Roland Stuck for developing the air file for the 28 and for the help with the panel
   Max Roodveldt for designing the gauges
   Everyone else for being so patient for this release!


Copyright disclaimer

This aircraft is released as Freeware. Copyright � Peter Franke.  As freeware you may distribute this archive subject to the following conditions:

   - This package may be freely copied and distributed as long as it is not modified and no charges are made for the distribution.
   - The release of a repainted version of this model is not allowed without the written permission of the author. 
   - Selling this package or any part of it is not allowed without the written permission of the author.

April 2002

Peter Franke

pet_fra@hotmail.com
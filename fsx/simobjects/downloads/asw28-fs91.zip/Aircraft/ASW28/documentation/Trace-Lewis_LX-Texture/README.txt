place these files into the aircrafts root folder.
be sure to backup aircraft.cfg file

  ENJOY!


  Trace Lewis
  age 13
  curtl33@aol.com
This is an FS9 (FS2004) patch for Peter Franke's
ASW-28 model. The original distribution is required.


Installation instructions:
-------------------------

Please first install Peter Franke's ASW-28 from the
original fs2002 installer (available on SOAR website).

Next, expand the archive in a temporary directory and
move the files into place. Below is a listing of the files
included in the archive. Alternatively, expand this zip
archive at the root of your FS9 installation (for
example, in C:\FlightSim\FS2004). Be forewarned, however,
that I have not tested that installation method...

  +---Aircraft
  |   \---ASW28
  |       |   aircraft.cfg
  |       |   asw28vet.air
  |       |
  |       \---panel
  |               main.bmp
  |               panel.cfg
  |
  \---Gauges
          mr-asw28.gau
          mr-fs9-caiset.gau
          mr-screws.gau
          mr-yawstring.gau
   
      README.txt
      kf-license.txt


Please see the documentation included in the original
distribution for copyrights, disclaimers, warranties, etc.

Please also read the file kf-license.txt in this archive
which pertains to my contributions to this project, including
these installation instructions. My contributions are
provided ``as is'' and without warranties.


Credits:
-------

Panel and gauges have been upgraded for FS9 by Max Roodveldt.
Flight dynamics have been upgraded for FS9 by Kris Feldmann.

Everything else is original. Please see the original
documentation for complete credits and other important
details.

Thanks to everyone on the SOAR forum for all the help, advice,
beta testing and support!


Enjoy,

Kris Feldmann <kris@rotted.com>
2004/04/01

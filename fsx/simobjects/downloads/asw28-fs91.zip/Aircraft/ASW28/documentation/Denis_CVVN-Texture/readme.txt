Hi,

To fly with the EM, you have to :

- Copy the folder texture.cnvv in the ASW28 folder
- Add these lines in the aircraft.cfg file (opened with wordpad).



[fltsim.xx]   (xx is the number of the next)
title=Schleicher ASW-28 (metric - CFHN)
sim=asw28vetwet 
model=
panel= 
sound=
texture=cvvn
checklists=
visual_damage=1
description=Model du planeur du CVVN de St Auban by Schleicher. 
ui_manufacturer=Schleicher
ui_type= ASW 28 VET 
ui_variation=CFHN(St auban)
atc_heavy=0
atc_id=
atc_airline=
atc_flight_number=




Then save the aircraft.cfg file and quit wordpad

Good flight

Denis
guerinds@ensma.fr
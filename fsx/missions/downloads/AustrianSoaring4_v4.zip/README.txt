Austrian Soaring - Day 4

INTRODUCTION

Austrian Soaring - Day 4 is the third mission (after Day 2, Day 3) designed as follow-ons to the FSX Deluxe Austrian Soaring mission, with the idea that you fly each mission in turn representing consecutive days in a soaring competition based at Zell am See, Austria. Day 4 is a little harder than the prior days as the weather is less favourable, particularly in the North-East of the course. There is no requirement to install or complete the earlier missions but I suspect you will enjoy this mission more if you do.

INSTALLATION INSTRUCTIONS

These instructions refer to your FSX base install folder as FSXBASE.  It is usually "C:\Program Files\Microsoft Games\Microsoft Flight Simulator X"

INSTALLATION IS JUST THE PROCESS OF DRAGGING THE FILES FROM THIS ZIP FILE INTO THE RIGHT PLACES IN YOUR FSX INSTALL.

1) CREATE 'Soaring' CATEGORY.
    SKIP TO STEP 2 IF YOU ALREADY HAVE THE 'Soaring' MISSION CATEGORY DEFINED. If you DO NOT already have the 'Soaring' FSX Mission category defined:
     * open 'SoaringCategory.zip' and follow the instructions in that README.txt
     * (note: this simply adds the 'Soaring' category to your missions by putting an xml file into your FSXBASE\Categories folder)
     * now you should have an 'FSXBASE\Categories\SoaringFSCategories.xml' file

2) INSTALL THE REWARD
    Drag the file 'Rewards\AustrianSoaring4_rwd.RWD' from this zip file into your   FSXBASE\Rewards folder, i.e. you should end up with a file called 'FSXBASE\Rewards\AustrianSoaring4_rwd.RWD'
   
3) INSTALL THE "Austrian Soaring - Day 4" MISSION:
     * drag the folder 'Soaring\AustrianSoaring4' into your 'FSXBASE\Missions\Soaring' folder
       i.e. you should end up with a FSXBASE\Missions\Soaring\AustrianSoaring4 folder.

When you run FSX and look at Missions you should see "Austrian Soaring - Day 4" listed as an Advanced mission. The prior missions in the Austrian Soaring competition were all 'Intermediate' skill level, so please note this new mission will not appear next to those by default in your mission list, unless you filter on the 'Soaring' category.

If you have lots of missions installed you can select 'Soaring' in the Missions Category drop-down box.

Any questions, try the www.fsxmission.com 'Missions' forum.

Brought to you by B21. Thanks to Hodge for testing and comments.

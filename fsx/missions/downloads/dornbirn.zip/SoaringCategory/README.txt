'Soaring' mission category for FSX

INSTALLATION:

1) open SoaringCategory.zip in Windows Explorer

2) to have FSX understand the 'Soaring' category:
drag the *files* from the 'Categories' folder in the zip into your FSX 'Categories' folder
(this is just the 'xml' file FSX understands, plus the BMP image displayed for the category)

3) to create the folder to hold your soaring missions
drag the 'Soaring' *folder* from the zip into your FSX 'Missions' folder
(this is just an empty folder except for the 'category_images' folder with images used by most missions)

COMPLETED...

then any new soaring missions can simply be placed in your Missions/Soaring folder and
will automatically appear on the missions page in FSX.

CREDITS:

Soaring category created by Beeg

Package created for upload by B21

For soaring mission development tutorial see http://www.forsterlewis.com/soaring/sim/fsx

Any questions try the Missions forum on http://www.fsxmission.com
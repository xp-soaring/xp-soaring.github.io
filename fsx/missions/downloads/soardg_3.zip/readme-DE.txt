
EINF�HRUNG:
=============

SOAR DG808S V3 (soardg_3.zip)

Dieses Paket enth�lt eine Reihe von Verbesserungen des Flugverhaltens und der Instrumente der DG808S
im Microsoft Flugsimulator FSX, au�erdem zwei Segelflugmissionen, die dieses Flugzeug verwenden.

Die Version V3 �berschreibt die fr�heren Versionen der SOAR DG808S V1 oder V2, falls sie installiert 
sind, setzt diese bei der Installation aber nicht voraus. Die Flugeigenschaften sind identisch mit 
der Version V2. Im Wesentlichen erfolgt die Installation (s.u.) per drag-and-drop vom Archiv in den
Programmordner des FSX. Alle erforderlichen Informationen f�r eine vollst�ndige Installation befinden
sich in der vorliegenden Textdatei readme-DE.txt.

Die weiteren readme-Dateien (readme_Sounds.txt and readme_TrimWizard.txt) enthalten zus�tzliche
Informationen �ber die neuen Sound-Effekte und den TrimWizard.

Nach der Installation ist die SOAR DG808S �ber das Flugzeugmen� abrufbar, z.B. �ber die Auswahl 
"SOAR Virtualsoaring.org" in der Rubrik "Herausgeber".

VORAUSSETZUNGEN:
===============

Die Missionen erfordern folgende zu�tzliche Software-Module:

* CumulusX! von http://luerkens.homepage.t-online.de/peter/

F�r den maximalen Segelflugspa� sollte man au�erdem das folgende Modul verwenden:

* sim_probe von http://carrier.csi.cam.ac.uk/forsterlewis/soaring/sim/fsx/dev/sim_probe/

INSTALLATION:
=============

Zusammengefasst: Einfach jeden einzelnen Ordner aus dem Zip-Archiv in den FSX-Programm-Ordner ziehen.

Im Einzelnen: Um die SOAR DG808S zu installieren:

- Kopiere den Ordner SimObjects aus diesem Paket in den FSX-Programm-Ordner

Um die Missionen mit diesem Flugzeig zu installieren:

- Kopiere den Ordner "Missions" aus dem Archiv in den FSX-Programm-Ordner

- Kopiere den Ordner "Categories" aus dem Archiv in den FSX-Programm-Ordner

- Kopiere den Ordner "Rewards" aus dem Archiv in den FSX-Programm-Ordner

Lokalisierung:
Das Archiv enth�lt auch eine Datei "aircraft.cfg.DE" , die die deutsche Beschreibung der DG808S 
enth�lt. Diese wird nach den vorherigen Schritten in den Ordner 

...\SimObjects\Airplanes\DG808S_SOAR 

kopiert. Die dort vorhandene Datei "aircraft.cfg" wird gel�scht und die Datei "aircraft.cfg.DE" in 
"aircraft.cfg" umbenannt.


DE-INSTALLATION:
================

- L�schen des Ordners Simobjects\Airplanes\DG808S_SOAR\

Wenn die Missionen installiert worden sind:

- L�schen der Dateien Rewards\SOAR Mifflin day 1.RWD und SOAR_Nationals_Mifflin_day1.RWD

- L�schen des Ordners Missions\Soaring\SOAR_Mifflin_Day1 and SOAR_Nationals_Mifflin_Day1

Falls keine weiteren Soaring-Missionen installiert wurden:

- L�schen des Orndners Missions\Soaring

- L�schen der Datei Categories\banner_soaring.bmp

- L�schen der Datei Categories\SoaringFSCategories.xml



================ BESCHREIBUNG DER VERBESSERUNGEN =============================

Das Paket enth�lt:

(1) Aerodynamische Verbesserungen:

Polare (Auftriebs/Widerstands Verh�ltnis i.A. der Geschwindigkeit), Bremsklappen-Verhalten,
Gier-Verhalten und Wirkung der W�lbklappen entsprechen wesentlich besser dem Verhalten der realen 
DG808S.

(2) Verbesserungen im Instrumentenbrett: 

Die Positionen des Winter-Varios und des H�henmessers wurden getauscht um dem Vario mehr in den 
Aufmerksamkeitsbereich zu verschieben. Das Winter-Vario ist nun total-energie-kompensiert, d.h. dass 
Steig- und Sinkanzeigen beim Bewegen des Steuerkn�ppels weitestgehend unterdr�ck werden. Das 
Cambridge-Vario arbeitet nun als Netto-Vario, d.h. es zeigt die Steiggeschwindigkeit der umgebenden 
Luft, nicht des Flugzeuges, an. Dies erfordert eine komplizierte Berechnung, die sowohl die 
Total-Energie als auch die Gleitzahl-Polare des Flugzeugs ber�cksichtigt. Au�erdem zeigt es die 
Ankunftsh�he (Fu� oder Meter) am n�chsten Wendepunkt (aus Flugplan/GPS), abh�ngig von 
Windgeschwindigkeit und Richtung, aktueller H�he und "McCready-Wert" (einstellbar �ber die (+) und 
(-) Kn�pfe). Gew�hnlich stellt der Pilot den McCready-Wert auf die durchschnittlich zu erwartende 
St�rke der Aufwinde ein, um eine m�glichst hohe Durchschnittsgesschwindigkeit zu erzielen. Au�erdem 
wird die Stellung der W�lbklappen angezeigt.

(3) Neue Segelflug-Mission - Die 373 km-Aufgabe von der realen USA Meisterschaft der 18-m-Klasse 2008

(4) Bug-Fixes seit der Ver�ffentlichung von SOARDG_1 & SOARDG_2

a. Einige Instrumente fehlten im 2D-Panel der SOARDG_1

b. In der Flugzeugliste tauchte die SOAR-Variante als separates Flugzeug erst am Ende auf

c. Die Flugleistungen bei geringen Geschwindigkeiten entsprechen besser dem Original

d. Slip (Seitengleitflug) f�r sehr steile Lande-Anfl�ge ist nun m�glich.

e. Anpassung der Instrumente an die ge�nderten Flugleistungen

f. Bug-Fixes beim Cambridge Vario, insbesondere ein Fehler bei der Anzeige der Ankunftsh�he
   beim Thermikkreisen in Missionen.

g. Verbesserte Cockpit-Ger�usche, einschlie�lich Fahrwerk Ein/Aus, Fahrwerkswarnung, 
   Bremsklappen und Einrasten der W�lbklappen

h. Neue Funktion "TrimWizard", halb-automatische Anpassung der Kn�ppelneutralstellung wobei die 
   Trimmung automatisch so eingestellt wird, dass sich die L�ngsneigung beim Bewegen des Kn�ppels
   in die Neutralstellung nicht �ndert. Wird aktiviert durch Bet�tigen der Rad-Bremse.


Bekannte Probleme:
==================

W�hrend des Testens auf einem Vista-System konnte die Briefing-Information wegen 
Sicherheitseinstellungen im Internet-Explorer nicht in FSX angezeigt werden. Wenn dieses Probelm 
auftritt, kann der Inhalt des Briefings dennoch angezeigt werden, indem zuerst mit dem Windows-
Explorer das Eigenschafts-Kontext-Men� der Dateien mit der Endung .htm im Verzeichnis 
"missions\Soaring\SOAR_Mifflin_day_1 folder" ge�ffnet und der Button "Zulassen" angeklickt wird.



Credits
=======

Bert de Bruin, Ian Forster-Lewis, Peter Luerkens
Microsoft f�r die originale DG808S.

Bmerkungen und Kommentare zu dieser Version k�nnen auf dem Forum von www.virtualsoaring.org geposted
werden. Dieses ist der Treffpunkt der SOAR community an dem Bert, Ian, Peter und andere Segelflug-
Fans regelm��ig anzutreffen sind und FSX-Segelflug-Erfahrungen austauschen

RECHTLICHES
===========
Die Benutzung des Materials aus diesem Paket innerhalb von FSX ist kostenlos.

Es darf nicht mit kommerziellen Produkte vereint oder verteilt werden.

Die Benutzung erfolgt auf eigene Gefahr.

Die Autoren �bernehmen keine Verantwortung f�r sch�dliche Auswirkungen oder andere unerw�nschte Effekte
auf dem Computer des Benutzers.

Insbesondere lehnen die Autoren jede Verantwortlichkeit ab f�r das Eingew�hnen von unpassenden 
Praktiken und Verhaltensweisen durch den Gebrauch dieses Paketes in Bezug auf die Erfordernisse der 
realen Luftfahrt.

Die Datei panel.cfg basiert auf der originalen FSX DG808S von Microsoft und der modifizierten Version 
der SOAR DG808S und wird hier ver�ffentlicht unter Microsoft's Game Content Usage Rules, ver�ffentlicht 
bei: http://www.xbox.com/en-US/community/developer/rules.htm

Das Modul dsd_fsx_xml_sound3.gau ist Copyright Douglas S. Dawson (douglassdawson@netscape.net).
Kommerzielle Verwendung ist untersagt.

Kommerzielle Verwendung des Instruments DGSound.xml ist nicht erlaubt.

Die modifizierten Dateien aircraft.cfg, virtualsoaring.air, die enthaltenen Variometer-Intrumente und das modifizierte Instrumentenbrett wurden hergestellt und ver�ffentlicht unter Microsoft�s
�Game Content Usage Rules� unter Verwendung von Elementen des Microsoft Flugimulator X (FSX), � Microsoft
Corporation(http://www.xbox.com/en-US/community/developer/rules.htm)

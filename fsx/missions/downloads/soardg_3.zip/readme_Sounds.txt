
Introduction:
==============

SOAR DG808S SOUND ADDON 1.0 (DG808S_SOAR_sound_1.zip)

This package includes an additional sounds package for the FSX SOAR DG808S only. The SOAR DG808S (soardg_2.zip or newer versions) can be downloaded from the download section of www.virtualsoaring.org.

After installing this sound package the SOAR DG808S will be equiped with:
- the sound of the gear going up or down;
- the sound of setting the flaps;
- the sound of unlocking or locking the air-brakes;
- a warning sound when unlocking airblakes while gear is still up.  



INSTALLATION:
=============

1.
Make sure to have a working installation of the SOAR DG808S.

2.
Backup panel.cfg from the FSX\Simobjects\airplanes\ DG808S_SOAR\Panel.virtualsoaring folder or rename panel.cfg to something like panel.cfg.orig

3.
Just drag the folder "Simobjects" from the zip into your FSX main folder...


DE-INSTALLATION:
================

1. 
Delete the following files from the FSX\Simobjects\airplanes\ DG808S_SOAR\Panel.virtualsoaring folder:
- DGSounds.xml;
- dsd_fsx_xml_sound3.dll;
- panel.cfg
- DSD_DG808S.ini

2. Restore the backupped original panel.cfg into the FSX\Simobjects\airplanes\ DG808S_SOAR\Panel.virtualsoaring folder
or rename the panel.cfg.orig back to panel.cfg


KNOWN-ISSUE:
=============
Gear warning and spoiler sound will be heard when in outside view. There is no suppression of spoiler and gear warning sound in outside view.


CREDITS
=======
Doug Dawson for his extremely useful sound module dsd_fsx_xml_sound3.dll which is included with his kind permission.

Many thanks to Bert de Bruin and Dirk Boehm for testing and consistency check.

Any comments on this release can be posted on the messageboard of
www.virtualsoaring.org, the SOAR meeting place that Bert, Ian and Peter and other soaring fanatics visit on a regular basis to exchange new FSX soaring experiences.


LEGAL STUFF
===========
Usage of this package is free-of-charge.

It must not be combined or distributed in conjunction with commercial products.

Usage is on own risk.

The author does not take responsibility for negative or otherwise unwanted side effects on the computer of the user.

In particular the author does not accept any responsibility for adoption of improper skills in relation to real aviation due to the usage of the package.

The file panel.cfg is based on the original FSX stock DG808S and the modified version of the SOAR DG808S and is released under Microsoft's Game Content Usage Rules, published at: 
http://www.xbox.com/en-US/community/developer/rules.htm

The module dsd_fsx_xml_sound3.gau is copyrighted by Douglas S. Dawson (douglassdawson@netscape.net). Commercial use is prohibited.

Commercial use of the gauge DGSound.xml is not allowed.

Peter L�rkens (peter.luerkens@t-online.de)
Aachen, Germany
Dec. 3rd, 2008

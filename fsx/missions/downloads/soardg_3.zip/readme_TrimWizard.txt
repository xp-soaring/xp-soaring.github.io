TrimWizard Gauge for FSX
========================
This gauge makes it very easy to neutralize stick and yoke forces for the current attitude. It is primary meant for glider planes. Most modern gliders do not have an aerodynamic trim or even a displacable ballast mass, but simply use an adjustable spring to define the stick's neutral position. Some gliders, e.g. LS and DG use kind of a trigger at the stick to release the spring temporarily, which can relax now, and then is fastened again to define the current position as the new neutral position. This gauge mimics this behavior as close as possible with a non-FFB stick.
It can be used probably for any aircraft, too, and was tested also with the stock C172 and B747. It is probably not very realistic to use it for helos.

Know-your-systems, principle of operation
=========================================
Basically, the gauge performs a sort of pitch autopilot, i.e. it freezes the current pitch by constantly and quickly adjusting the trim. This means you can almost freely move the stick to and fro while the plane holds its pitch angle. The action is started by activating the aircraft brakes, which is usually irrelevant, when airborne. As long as the brakes are activated, the current pitch is maintained and the stick can be brought to the desired position, usually the neutral position. After releasing the brake button, pitch freezing is terminated and normal control continues.
Except from per-plane installation, there is no configuration or tuning required.

Installation
============
If you plan to use the gauge with several aircraft, put the included xml-file perferably into FSX' gauge folder. Otherwise, put it directly into the panel folder of the target aircraft.
Make a backup copy of the aircraft's panel configuration. Then open the aircraft's panel.cfg, go to a panel section and add a line:

gauge08=.!TrimWizard, 0,0

where you have to replace 08 with the number of the last gauge in this section, plus 1. I had put it into one of the virtual cockpit sections, because virtual cockpit is typically activated by default in FSX. Most likely it will work with any other panel section anyway. The gauge itself is invisible.

Un-Installation
===============
Restore the original panel-configuration and delete the xml-file from the system.

Credits
=======
Ian Lewis and Bert de Bruin for testing.

Legal
=====
Usage of this package is free-of-charge.
It must not be combined or distributed in conjunction with commercial products.
Usage is on own risk.
The author does not take responsibility for negative or otherwise unwanted side effects on the computer of the user.
In particular the author does not accept any responsibility for adoption of improper skills in relation to real aviation due to the usage of the package.

Copyright Peter L�rkens, Dec. 3rd, 2008

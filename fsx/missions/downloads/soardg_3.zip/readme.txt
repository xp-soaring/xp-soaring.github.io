
INTRODUCTION:
=============

SOAR DG808S V3 (soardg_3.zip)

(((For Germany see readme-DE.txt)))

This package gives a number of improvements to the aerodynamic simulation
and instruments of the FSX DG808S, plus two soaring mission using that
aircraft.

The V3 package *replaces* SOAR DG808S V1 or v2 *if* you have either already installed,
but equally can be installed stand-alone.  The V3 flight performance is the *same* as V2.

The installation instructions are below, via simple drag-and-drops from the
zip file into your FSX program folder. 

FOR FULL INSTALLATION, YOU ONLY NEED TO READ *THIS* readme.txt

The other two readme's included (readme_Sounds.txt and readme_TrimWizard.txt) are included
if you want more detail on how those particular features were installed with the DG.

When installed, the virtualsoaring DG808S is available on the Aircraft
Selection panel - choose 'virtualsoaring' from the 'Publisher' drop-down.

PRE-REQUISITES:
===============

The *missions* require:

* CumulusX! from http://luerkens.homepage.t-online.de/peter/

For the full soaring experience you should also have:

* sim_probe from http://carrier.csi.cam.ac.uk/forsterlewis/soaring/sim/fsx/dev/sim_probe/

INSTALLATION:
=============

In summary - just drag each folder from the zip into your FSX main folder...

In detail: To install the SOAR DG808S:

- Copy the SimObjects folder from this zip into your main FSX program folder

To install the missions that uses this aircraft;

- Copy the Missions folder from this zip into your main FSX program folder

- Copy the Categories folder from this zip into your main FSX program folder

- Copy the Rewards folder from this zip into your main FSX program folder



De-installation:
================


- delete the folder Simobjects\Airplanes\DG808S_SOAR\

If you installed the missions:

- delete the files Rewards\SOAR Mifflin day 1.RWD and SOAR_Nationals_Mifflin_day1.RWD

- delete the folders Missions\Soaring\SOAR_Mifflin_Day1 and SOAR_Nationals_Mifflin_Day1

If you have no other 'Soaring' missions, you can

- delete the folder Missions\Soaring

- delete the file Categories\banner_soaring.bmp

- delete the file Categories\SoaringFSCategories.xml



================ IMPROVEMENTS IN DETAIL =============================

The package includes:

(1) Aerodynamic improvements:

the polar (lift/drag ratio at each speed), the airbrakes behaviour, yaw behaviour, and the flaps effects have been altered to make them far closer to the real DG808S.

(2) Instrument improvements: 

the Winter vario and the altimeter have swapped positions giving the vario the precendence you'd expect in a glider. The Winter has also been programmed to display compensated 'total energy' rather than simple vertical speed - this eliminates the 'stick thermals' caused simply by pulling back on the joystick.  The cambridge has been programmed to display 'Netto', i.e. the vertical movement of the air *outside* the glider.  This is a complex calculation that uses both the 'total energy' value and an adjustment due to the L/D performance of the aircraft at the current speed.  The Cambridge also displays 'Arrival Height' at next waypoint in either feet or meters based on the distance to go to the next waypoint in the mission or the GPS, wind speed and direction, current altitude, and also the 'Mccready setting' which is adjustable via new clickable (+) and (-) areas on the dial. The mccready setting (in knots or meters per second) is the expected strength of climb set by the pilot.  As a minor addition, the Cambridge vario also displays the current flap setting, from -2 to +4.

(3) Another soaring mission has been included - the 373km task set for the real 2008 USA 18m Nationals.

(4) Fixed issues and bugs after the release of SOARDG_1 & SOARDG_2

a. Some gauges in 2D-view didn't show up with SoARDG_1

b. In the Aircraft Selection Panel the SOAR-variant was listed as a separate airplane at the bottom of the airplane list;

c. the performance at low speed has been made more accurate.

d. side-slipping is now possible.

e. as a result of the performance-improvements some of the instruments have been re-calibrated.

f. bug-fixes have been applied to the Cambridge vario, in particular an error affecting the reading
   of the 'Arrival Height' indication while circling in thermals in a mission.

g. Sounds have been enhanced - gear up/down plus a gear-up warning, flap selection, airbrakes in/out.

h. 'TrimWizard' has been incorporated - the brake button maintains pitch while held down. 


Known-issue:
===========

During testing on a Vista computer the mission briefing information did not show in FSX. This was due to security reason of either Vista or the installed firewall, which was blocking the file template_overview_tab.htm with an activex warning (although the file
contains *no* activex). If that happens to you, use the Explorer to
search for that file in the SOAR_Mifflin_day1 folder, open the properties window by right-clicking on the file, choose properties-> general and click the unblock button at the bottom of the properties window. Click ok and the problem should be solved in FSX. This should be repeated for the other .htm files in the missions\Soaring\SOAR_Mifflin_day_1 folder if you have this issue.



Credits
=======

Bert de Bruin, Ian Forster-Lewis, Peter Luerkens
Microsoft for the original DG808S.

Any comments on this release can be posted on the messageboard of
www.virtualsoaring.org, the SOAR meeting place that Bert, Ian and Peter and other soaring fanatics visit on a regular basis to exchange new FSX soaring experiences.

LEGAL STUFF
===========
Usage of this package is free-of-charge within FSX.

It must not be combined or distributed in conjunction with commercial products.

Usage is on own risk.

The authors do not take responsibility for negative or otherwise unwanted side effects on the computer of the user.

In particular the author does not accept any responsibility for adoption of improper skills in relation to real aviation due to the usage of the package.

The file panel.cfg is based on the original FSX stock DG808S and the modified version of the SOAR DG808S and is released under Microsoft's Game Content Usage Rules, published at: 
http://www.xbox.com/en-US/community/developer/rules.htm

The module dsd_fsx_xml_sound3.gau is copyrighted by Douglas S. Dawson (douglassdawson@netscape.net). Commercial use is prohibited.

Commercial use of the gauge DGSound.xml is not allowed.

The modified aircraft.cfg, virtualsoaring.air, the included vario gauges and the modified panel were created under Microsoft�s
�Game Content Usage Rules� using assets from FSX, � Microsoft
Corporation(http://www.xbox.com/en-US/community/developer/rules.htm)

Austrian Soaring - day 3

INSTALLATION INSTRUCTIONS

1) If you DO NOT already have the 'Soaring' FSX Mission category defined:
     * open 'SoaringCategory.zip' and follow the instructions in that README.txt
     
2) If you DO NOT already have the b21_gliders scenery installed
     * copy the folder 'Addon Scenery/b21_gliders' into your FSX 'Addon Scenery' folder
     * within FSX/Settings/Scenery Library, add the folder 'Addon Scenery/b21_gliders' to your active scenery
     * note - when you start the mission you might think you can't see other gliders so this scenery install
       failed, but please fly through the start before reaching that conclusion.  Even though there are 50
       other gliders simulated in the mission, they are damn hard to spot in the air.

2) To install the Austrian Soaring - day 3 mission:
     * copy the folder Soaring/AustrianSoaring3 into your 'Missions/Soaring' folder
       i.e. you should end up with a Missions/Soaring/AustrianSoaring3 folder in
       your FSX root directory.

Any questions, try the www.fsxmission.com 'Missions' forum.

Brought to you by B21.

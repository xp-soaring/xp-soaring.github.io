Mifflin patch

Installation instructions:
===========================

drag the Missions folder from this zip file into your FSXMAIN folder, usually

C:\Program Files\Microsoft Games\Microsoft Flight Simulator X\


Comments
========

This 'v9' patch includes the 'v8' patch which improves the alignment of the 'finish' line for Day 3.

This 'v9' patch extends the max duration of the timer on Day 3 from 2 hours 40 to over 7 hours.

This 'v9' patch replaces the WX files in each mission folder to make the cumulus layer constant throughout
the area, giving more consistent thermals to all players.

The application of this 'v9' patch will update any earlier download of the Mifflin missions to the same as
the current 'mifflin_v9.zip' full download version.

B21


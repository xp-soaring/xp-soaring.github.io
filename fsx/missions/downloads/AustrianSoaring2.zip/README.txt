Austrian Soaring - day 2

INSTALLATION INSTRUCTIONS

1) If you DO NOT already have the 'Soaring' FSX Mission category defined:
     * open 'SoaringCategory.zip' and follow the instructions in that README.txt


2) To install the Austrian Soaring - day 2 mission:
     * copy the folder Soaring/AustrianSoaring2 into your 'Missions/Soaring' folder
       i.e. you should end up with a Missions/Soaring/AustrianSoaring2 folder in
       your FSX root directory.

Any questions, try the www.fsxmission.com 'Missions' forum.

Brought to you by B21.

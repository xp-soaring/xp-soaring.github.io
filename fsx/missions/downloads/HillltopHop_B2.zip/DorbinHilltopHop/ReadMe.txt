Dornbirn Hilltop Hop
Beta 2

This is my first attempt at a fsx mission.
The first anual - prestigous - ficticous - timed sailplane race over and around a few hilltops in Austria.
Total mission time : about an hour 
Race time          : alittle less

Before flying this mission cumulusx, sim_probe, and the SOAR DG must be installed
if you don't have them, get the b21's SOAR Mifflin day 1 
his directions are better than mine could ever be



installation

unzip into your fsx ... soaring folder
should show up in soaring cat

i hope

so ... what time did you get?
# B21 SASL

This is an X-Plane 'aircraft' plugin written using the SASL Lua system.

* provide a 'netto' vario value for the ASK21
